//
//  SplashViewController.swift
//  AnimationButtonClick
//
//  Created by MacBook Pro on 21/12/2023.
//

import UIKit

class SplashViewController: UIViewController {
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        activityIndicator.startAnimating()
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
            self.activityIndicator.stopAnimating()
            self.performSegue(withIdentifier: "ShowMainScreen", sender: self)
        }
    }
}
